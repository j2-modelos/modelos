# Change Log

## v0.3.1 / 2017-11-25
### Fixed
- package.json typo #24

## v0.3.0 / 2016-02-17
### Added
- data-lazyload attribute to load content.
- script type="text/lazyload" to load content.
- Supported text content.

## v0.2.3 / 2014-10-21
### Added
- refresh method for element move.

### Fixed
- JSHint warnings.

## v0.2.2 / 2014-10-21
### Imporved
- performance.

### Changed
- Enable event if document is not ready.

## v0.2.1 / 2014-10-21
### Imporved
- performance.

### Fixed
- trim bug in older browsers.

## v0.2.0 / 2014-10-12
### Added
- Support overflow div.
- Support display none and show.

## v0.1.9 / 2014-09-23
### Added
- Bind resize and scroll events only on demand.

## v0.1.8 / 2014-07-27
### Added
- Support for jquery 1.6.4

## v0.1.7 / 2014-07-01
### Added
- Support for jquery 1.9.1

## v0.1.6 / 2014-04-29
### Added
- detection when initializing.

## v0.1.5 / 2014-04-24
### Added
- Support older version jQuery(test 1.6.4).

## v0.1.4 / 2014-02-04
### Fixed
- Rewrite to avoid event listener lost.

## v0.1.3 / 2014-02-03
### Added
- trigger option.

## v0.1.2 / 2014-01-28
### Added
- load callback.

## v0.1.1 / 2014-01-22
### Added
- x-axis detection.
- threshold.

## v0.1.0 / 2014-01-19
### Added
- Initial release
